package com.mongo;

import com.mongo.app.Application;

public class Main {
    public static void main(String[] args) {
        Application app = new Application();
        app.start();
    }
}